require "test_helper"

class CallAfterDialJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
