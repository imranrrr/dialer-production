require "test_helper"

class DialstogroupTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
