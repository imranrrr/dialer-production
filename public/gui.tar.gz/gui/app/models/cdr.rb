class Cdr < ApplicationRecord
end
