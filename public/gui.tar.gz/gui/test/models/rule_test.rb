require "test_helper"

class RuleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
