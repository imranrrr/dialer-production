#! /bin/sh

# Precompile assets for production
bundle exec rake assets:precompile

echo "Assets Pre-compiled!"
