require "test_helper"

class CallEachUserJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
