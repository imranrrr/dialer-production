class Log < ApplicationRecord
end
