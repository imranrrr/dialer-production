require "test_helper"

class CdrTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
